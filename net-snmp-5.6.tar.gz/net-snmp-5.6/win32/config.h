/*
 * Everyone should be including the new style config header.
 * For now, we'll do it for them for backwards compatability.
 */
#include <net-snmp/net-snmp-config.h>
